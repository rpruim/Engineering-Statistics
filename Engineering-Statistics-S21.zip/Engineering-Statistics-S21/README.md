# Engineering-Statistics
Course notes for Math 241.  A branch of the original by Randall Pruim (rpruim on Github).

